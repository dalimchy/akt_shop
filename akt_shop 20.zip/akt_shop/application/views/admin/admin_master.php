<?php
$this->load->view('admin/head');
$this->load->view('admin/aside');
?>


<?php echo $admin_main_content; ?>



<?php
$this->load->view('admin/foot');
?>
